from __future__ import annotations

import json
from pathlib import Path
from dataclasses import dataclass, field
from typing import Any


# --- Structures de données standard ---

@dataclass
class AlgoInput:
    """Entrée normalisée d'un algorithme réglementaire."""
    data: dict[str, Any]
    context: dict[str, Any] = field(default_factory=dict)


@dataclass
class AlgoResult:
    """Sortie normalisée d'un algorithme réglementaire."""
    value: Any
    algo_id: str
    regulation: dict[str, str]
    inputs_snapshot: dict[str, Any]
    metadata: dict[str, Any] = field(default_factory=dict)


# --- Implémentation de l'algorithme ---

class DroitVoteAlgorithm:
    """
    Éligibilité au droit de vote en France selon le Code électoral.

    Conditions cumulatives (Art. L.2 à L.7) :
        - Posséder la nationalité française (Art. L.2)
        - Être âgé d'au moins 18 ans (Art. L.3)
        - Ne pas être privé de ses droits civiques (Art. L.5, L.6)
        - Être inscrit sur les listes électorales (Art. L.7)
    """

    def __init__(self) -> None:
        _meta_path = Path(__file__).parent / "metadata.json"
        self._metadata = json.loads(_meta_path.read_text())

    @property
    def algo_id(self) -> str:
        return self._metadata["dct:identifier"]

    @property
    def regulation(self) -> dict[str, str]:
        return self._metadata["cprmv:isBasedOn"]

    def compute(self, algo_input: AlgoInput) -> AlgoResult:
        """
        Détermine si une personne a le droit de voter en France.

        Args:
            algo_input: Entrée contenant les attributs de la personne.

        Returns:
            AlgoResult avec True/False et la traçabilité complète.

        Raises:
            ValueError: Si l'âge est négatif.
        """
        nationalite = bool(algo_input.data["nationalite_francaise"])
        age = int(algo_input.data["age"])
        capacite = bool(algo_input.data["capacite_civique"])
        inscrit = bool(algo_input.data["inscrit_listes_electorales"])

        if age < 0:
            raise ValueError(f"L'âge doit être positif, reçu : {age}")

        peut_voter = nationalite and age >= 18 and capacite and inscrit

        return AlgoResult(
            value=peut_voter,
            algo_id=self.algo_id,
            regulation=self.regulation,
            inputs_snapshot=algo_input.data,
            metadata={
                "conditions": {
                    "nationalite_francaise": nationalite,
                    "age_suffisant": age >= 18,
                    "capacite_civique": capacite,
                    "inscrit_listes_electorales": inscrit,
                }
            },
        )